from bmtk.analyzer.cell_vars import plot_report

plot_report(config_file='simulation_config.json')
